for(var i = 0; i < 88; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

	SetPanelVisibility('u13','','fade',1000);

}

});

if (bIE) document.getElementById('u13').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u13'); });
else {
    document.getElementById('u13').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u13'); }, true);
    document.getElementById('u13').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u13'); }, true);
}

widgetIdToStartDragFunction['u13'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u73','','none',500);

}

}
gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'top';document.getElementById('u76_img').tabIndex = 0;

u76.style.cursor = 'pointer';
$axure.eventManager.click('u76', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货调整.html');

}
});
gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u34'] = 'top';document.getElementById('u81_img').tabIndex = 0;

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u85'] = 'top';document.getElementById('u71_img').tabIndex = 0;

u71.style.cursor = 'pointer';
$axure.eventManager.click('u71', function(e) {

if (true) {

	SetPanelVisibility('u78','','none',500);

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u58'] = 'top';document.getElementById('u83_img').tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u69'] = 'top';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货查询.html');

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';document.getElementById('u67_img').tabIndex = 0;

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

                                DisableImageWidget('u67');
	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u44'] = 'top';