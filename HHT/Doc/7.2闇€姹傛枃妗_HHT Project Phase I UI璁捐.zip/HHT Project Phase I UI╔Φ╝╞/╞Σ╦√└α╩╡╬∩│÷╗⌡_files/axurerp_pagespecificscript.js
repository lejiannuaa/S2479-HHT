for(var i = 0; i < 76; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'top';document.getElementById('u6_img').tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	SetPanelVisibility('u62','','none',500);

}
});
gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u66'] = 'center';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	SetPanelVisibility('u20','','none',500);

	SetPanelVisibility('u62','hidden','none',500);

}
});
gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u37'] = 'top';document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货作业.html');

}
});
gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'center';document.getElementById('u65_img').tabIndex = 0;

u65.style.cursor = 'pointer';
$axure.eventManager.click('u65', function(e) {

if (true) {

	SetPanelVisibility('u62','hidden','none',500);

}
});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u33'] = 'top';document.getElementById('u72_img').tabIndex = 0;

u72.style.cursor = 'pointer';
$axure.eventManager.click('u72', function(e) {

if ((false) || (false)) {

}
});
gv_vAlignTable['u18'] = 'top';document.getElementById('u67_img').tabIndex = 0;

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("提交成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

	SetPanelVisibility('u62','hidden','none',500);

	SetPanelVisibility('u20','hidden','none',500);

}
});
gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u59'] = 'top';