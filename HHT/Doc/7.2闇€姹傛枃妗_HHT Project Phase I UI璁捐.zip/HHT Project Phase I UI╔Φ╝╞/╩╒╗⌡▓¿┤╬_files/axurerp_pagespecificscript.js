for(var i = 0; i < 57; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u7'] = 'center';document.getElementById('u42_img').tabIndex = 0;

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	SetPanelVisibility('u13','','fade',500);

	SetPanelVisibility('u44','','fade',500);

	SetPanelVisibility('u47','','fade',500);

	SetPanelVisibility('u50','','fade',500);

	SetPanelVisibility('u53','','fade',500);

}
});
gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u24'] = 'top';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('查询_报表.html');

}
});
gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u34'] = 'top';