for(var i = 0; i < 80; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'center';document.getElementById('u46_img').tabIndex = 0;

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	SetPanelVisibility('u71','','none',500);

	SetPanelVisibility('u27','hidden','none',500);

	SetPanelVisibility('u34','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

	SetPanelVisibility('u55','hidden','none',500);

}
});
document.getElementById('u76_img').tabIndex = 0;

u76.style.cursor = 'pointer';
$axure.eventManager.click('u76', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('其他类实物出货.html');

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u38'] = 'top';document.getElementById('u32_img').tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('厂商_DC-新建_修改.html');

}
});
document.getElementById('u23_img').tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	SetPanelVisibility('u55','','none',500);

	SetPanelVisibility('u27','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

	SetPanelVisibility('u34','hidden','none',500);

	SetPanelVisibility('u71','hidden','none',500);

}
});
document.getElementById('u53_img').tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	SetPanelVisibility('u62','','none',500);

	SetPanelVisibility('u27','hidden','none',500);

	SetPanelVisibility('u34','hidden','none',500);

	SetPanelVisibility('u55','hidden','none',500);

	SetPanelVisibility('u71','hidden','none',500);

}
});
document.getElementById('u1_img').tabIndex = 0;

u1.style.cursor = 'pointer';
$axure.eventManager.click('u1', function(e) {

if (true) {

	SetPanelVisibility('u27','hidden','none',500);

	SetPanelVisibility('u34','hidden','none',500);

	SetPanelVisibility('u55','hidden','none',500);

}
});
document.getElementById('u7_img').tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	SetPanelVisibility('u27','','none',500);

	SetPanelVisibility('u34','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

	SetPanelVisibility('u55','hidden','none',500);

	SetPanelVisibility('u71','hidden','none',500);

}
});
gv_vAlignTable['u66'] = 'top';document.getElementById('u30_img').tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('厂商_DC-新建_修改.html');

}
});
gv_vAlignTable['u8'] = 'center';document.getElementById('u60_img').tabIndex = 0;

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('采购出货-修改.html');

}
});
document.getElementById('u19_img').tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	SetPanelVisibility('u34','','none',500);

	SetPanelVisibility('u27','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

	SetPanelVisibility('u55','hidden','none',500);

	SetPanelVisibility('u71','hidden','none',500);

}
});
gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u79'] = 'top';document.getElementById('u11_img').tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

}
});
gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u75'] = 'top';document.getElementById('u58_img').tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('采购出货-新建.html');

}
});
document.getElementById('u37_img').tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('调拨-门店-新建_修改.html');

}
});
gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'top';document.getElementById('u43_img').tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	SetPanelVisibility('u55','','none',500);

}
});
gv_vAlignTable['u0'] = 'top';document.getElementById('u3_img').tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('应用选择.html');

}
});
gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u54'] = 'center';document.getElementById('u39_img').tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('调拨-门店-新建_修改.html');

}
});
document.getElementById('u69_img').tabIndex = 0;

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('预约-查询.html');

}
});
document.getElementById('u78_img').tabIndex = 0;

u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('实物出货列印.html');

}
});
gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u26'] = 'top';document.getElementById('u65_img').tabIndex = 0;

u65.style.cursor = 'pointer';
$axure.eventManager.click('u65', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('预约-正常新建.html');

}
});
gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u18'] = 'center';document.getElementById('u67_img').tabIndex = 0;

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('预约-其他.html');

}
});
gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'center';document.getElementById('u74_img').tabIndex = 0;

u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('正常品实物出货.html');

}
});
gv_vAlignTable['u59'] = 'top';