for(var i = 0; i < 55; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

	SetPanelVisibility('u8','','fade',1000);

}

});

if (bIE) document.getElementById('u8').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u8'); });
else {
    document.getElementById('u8').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u8'); }, true);
    document.getElementById('u8').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u8'); }, true);
}

widgetIdToStartDragFunction['u8'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u50','','none',500);

}

}
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u23'] = 'top';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('采购出货-修改.html');

}
});
gv_vAlignTable['u46'] = 'top';document.getElementById('u53_img').tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u49'] = 'top';document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u34'] = 'top';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	SetPanelVisibility('u50','hidden','none',500);

}
});
