for(var i = 0; i < 98; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u76'] = 'center';document.getElementById('u6_img').tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("预约成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u77'] = 'top';document.getElementById('u93_img').tabIndex = 0;

u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if ((GetWidgetVisibility('u95')) == (true)) {

	SetPanelVisibility('u83','','none',500);

	SetPanelVisibility('u85','hidden','none',500);

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u30'] = 'top';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if ((GetWidgetVisibility('u83')) == (true)) {

	SetPanelVisibility('u70','','none',500);

}
});

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	SetPanelVisibility('u85','','none',500);

	SetPanelVisibility('u95','hidden','none',500);

	SetPanelVisibility('u62','','none',500);

}
});
gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u36'] = 'top';document.getElementById('u75_img').tabIndex = 0;

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	SetPanelVisibility('u70','hidden','none',500);

	SetPanelVisibility('u83','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

}
});
document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货作业.html');

}
});
gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u28'] = 'top';
u90.style.cursor = 'pointer';
$axure.eventManager.click('u90', function(e) {

if (true) {

	SetPanelVisibility('u95','','none',500);

}
});
document.getElementById('u73_img').tabIndex = 0;

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	SetPanelVisibility('u70','hidden','none',500);

}
});
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u67'] = 'top';document.getElementById('u88_img').tabIndex = 0;

u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if (true) {

	SetPanelVisibility('u85','hidden','none',500);

}
});
gv_vAlignTable['u57'] = 'top';document.getElementById('u10_img').tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (((GetCheckState('u51')) == (true)) || ((GetCheckState('u45')) == (true))) {

	SetPanelVisibility('u62','','none',500);

}
});
gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u80'] = 'top';