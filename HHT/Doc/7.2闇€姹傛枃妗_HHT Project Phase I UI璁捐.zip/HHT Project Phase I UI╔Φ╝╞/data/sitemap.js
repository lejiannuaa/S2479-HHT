﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m)]),_(c,n,e,f,g,o,i,[_(c,p,e,f,g,q),_(c,r,e,f,g,s),_(c,t,e,f,g,u)]),_(c,v,e,f,g,w,i,[_(c,x,e,f,g,y),_(c,z,e,f,g,A),_(c,B,e,f,g,C),_(c,D,e,f,g,E,i,[_(c,F,e,f,g,G)]),_(c,H,e,f,g,I),_(c,J,e,f,g,K),_(c,L,e,f,g,M,i,[_(c,N,e,f,g,O)]),_(c,P,e,f,g,Q),_(c,R,e,f,g,S)]),_(c,T,e,f,g,U,i,[_(c,V,e,f,g,W,i,[_(c,X,e,f,g,Y),_(c,Z,e,f,g,ba),_(c,bb,e,f,g,bc)]),_(c,bd,e,f,g,be),_(c,bf,e,f,g,bg)]),_(c,bh,e,f,g,bi)]);}; 
var b="rootNodes",c="pageName",d="登录及选择",e="type",f="Wireframe",g="url",h="登录及选择.html",i="children",j="登录",k="登录.html",l="应用选择",m="应用选择.html",n="收货作业",o="收货作业.html",p="调拨收货",q="调拨收货.html",r="短收原因维护",s="短收原因维护.html",t="PO收货明细",u="PO收货明细.html",v="出货作业",w="出货作业.html",x="厂商\/DC-新建\/修改",y="厂商_DC-新建_修改.html",z="调拨-门店-新建\/修改",A="调拨-门店-新建_修改.html",B="采购出货-新建",C="采购出货-新建.html",D="采购出货-修改",E="采购出货-修改.html",F="采购出货-调整",G="采购出货-调整.html",H="正常品实物出货",I="正常品实物出货.html",J="其他类实物出货",K="其他类实物出货.html",L="预约-正常新建",M="预约-正常新建.html",N="预约-查询",O="预约-查询.html",P="预约-其他",Q="预约-其他.html",R="实物出货列印",S="实物出货列印.html",T="查询&报表",U="查询_报表.html",V="出货查询",W="出货查询.html",X="出货明细",Y="出货明细.html",Z="出货明细失败",ba="出货明细失败.html",bb="出货调整",bc="出货调整.html",bd="收货波次",be="收货波次.html",bf="收货详细",bg="收货详细.html",bh="网络查看",bi="网络查看.html";
return _creator();
})();
