﻿var configuration = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,c,d,c,e,c);}; 
var b="showPageNotes",c=false,d="showPageNoteNames",e="loadFeedbackPlugin";
return _creator();
})()