for(var i = 0; i < 73; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});

if (bIE) document.getElementById('u13').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u13'); });
else {
    document.getElementById('u13').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u13'); }, true);
    document.getElementById('u13').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u13'); }, true);
}

widgetIdToStartDragFunction['u13'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u52','','none',500);

}

}
gv_vAlignTable['u16'] = 'top';document.getElementById('u55_img').tabIndex = 0;

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货明细.html');

}
});
gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u22'] = 'top';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	SetPanelVisibility('u52','hidden','none',500);

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u24'] = 'top';document.getElementById('u69_img').tabIndex = 0;

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	SetPanelVisibility('u13','','fade',500);

}
});
document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('查询_报表.html');

}
});
gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u59'] = 'top';