for(var i = 0; i < 84; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

	SetPanelVisibility('u13','','fade',1000);

}

});

if (bIE) document.getElementById('u13').attachEvent("onmousedown", function(e) { StartDragWidget(e, 'u13'); });
else {
    document.getElementById('u13').addEventListener("mousedown", function(e) { StartDragWidget(e, 'u13'); }, true);
    document.getElementById('u13').addEventListener("touchstart", function(e) { StartDragWidget(e, 'u13'); }, true);
}

widgetIdToStartDragFunction['u13'] = function() {
var e = windowEvent;

if (true) {

	SetPanelVisibility('u68','','none',500);

}

}
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'center';document.getElementById('u66_img').tabIndex = 0;

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u34'] = 'top';document.getElementById('u64_img').tabIndex = 0;

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u81'] = 'center';document.getElementById('u71_img').tabIndex = 0;

u71.style.cursor = 'pointer';
$axure.eventManager.click('u71', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('采购出货-调整.html');

}
});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'top';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	SetPanelVisibility('u68','hidden','none',500);

}
});
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u78'] = 'top';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货作业.html');

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u44'] = 'top';