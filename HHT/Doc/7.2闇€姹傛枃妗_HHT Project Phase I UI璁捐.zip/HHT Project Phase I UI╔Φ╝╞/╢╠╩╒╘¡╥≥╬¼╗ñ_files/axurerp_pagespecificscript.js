for(var i = 0; i < 47; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

	SetPanelVisibility('u8','','fade',1000);

}

});
gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u13'] = 'top';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href="javascript:history.back()";

}
});
gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u43'] = 'center';document.getElementById('u40_img').tabIndex = 0;

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href="javascript:history.back()";

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u34'] = 'top';