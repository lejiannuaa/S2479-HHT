for(var i = 0; i < 73; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u25'] = 'top';document.getElementById('u55_img').tabIndex = 0;

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	SetPanelVisibility('u52','hidden','none',500);

}
});
gv_vAlignTable['u23'] = 'center';document.getElementById('u62_img').tabIndex = 0;

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	SetPanelVisibility('u14','','none',500);

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u8'] = 'top';document.getElementById('u60_img').tabIndex = 0;

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	SetPanelVisibility('u52','','none',500);

}
});
gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u58'] = 'center';document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货作业.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'center';document.getElementById('u57_img').tabIndex = 0;

u57.style.cursor = 'pointer';
$axure.eventManager.click('u57', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

	SetPanelVisibility('u14','hidden','none',500);

	SetPanelVisibility('u52','hidden','none',500);

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u59'] = 'top';