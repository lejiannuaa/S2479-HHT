for(var i = 0; i < 64; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
document.getElementById('u36_img').tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if ((GetWidgetVisibility('u38')) == (true)) {

	NewWindow("resources/Other.html#other=" + encodeURI("请求成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

}
});
gv_vAlignTable['u17'] = 'top';
u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

}
});
gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u21'] = 'top';
u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	SetPanelVisibility('u50','','none',500);

	SetPanelVisibility('u60','hidden','none',500);

}
});
gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u43'] = 'top';document.getElementById('u44_img').tabIndex = 0;

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (((GetCheckState('u26')) == (true)) || ((GetCheckState('u29')) == (true))) {

	SetPanelVisibility('u38','hidden','none',500);

	SetPanelVisibility('u46','','none',500);

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u3'] = 'center';document.getElementById('u9_img').tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if ((GetWidgetVisibility('u11')) == (true)) {

	SetPanelVisibility('u38','','none',500);

	SetPanelVisibility('u11','hidden','none',500);

	SetPanelVisibility('u46','hidden','none',500);

}
});
gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u61'] = 'top';document.getElementById('u58_img').tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if ((GetWidgetVisibility('u60')) == (true)) {

	SetPanelVisibility('u11','','none',500);

	SetPanelVisibility('u50','hidden','none',500);

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u25'] = 'top';document.getElementById('u53_img').tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	SetPanelVisibility('u50','hidden','none',500);

}
});
gv_vAlignTable['u54'] = 'center';document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货作业.html');

}
});
gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u19'] = 'top';
u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	SetPanelVisibility('u60','','none',500);

}
});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u34'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

}
});
