for(var i = 0; i < 54; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u29'] = 'top';document.getElementById('u8_img').tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	SetPanelVisibility('u18','','none',500);

	SetPanelVisibility('u46','hidden','none',500);

}
});
gv_vAlignTable['u21'] = 'center';document.getElementById('u6_img').tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if ((GetWidgetVisibility('u18')) == (true)) {

	SetPanelVisibility('u46','','none',500);

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u53'] = 'top';document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('出货作业.html');

}
});
gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u48'] = 'center';document.getElementById('u49_img').tabIndex = 0;

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	SetPanelVisibility('u46','hidden','none',500);

}
});
gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u25'] = 'top';document.getElementById('u51_img').tabIndex = 0;

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	NewWindow("resources/Other.html#other=" + encodeURI("预约成功！"), "", "directories=0, height=300, location=0, menubar=0, resizable=1, scrollbars=1, status=0, toolbar=0, width=300", true, 300, 300);

	SetPanelVisibility('u18','hidden','none',500);

	SetPanelVisibility('u46','hidden','none',500);

}
});
gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u33'] = 'center';